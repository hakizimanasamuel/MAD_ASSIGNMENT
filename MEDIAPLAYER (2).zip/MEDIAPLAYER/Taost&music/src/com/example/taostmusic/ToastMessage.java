package com.example.taostmusic;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class ToastMessage extends Activity {
	public MediaPlayer jon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toast_message);
        Button toastmess=(Button)findViewById(R.id.toastm);
        Button btnstart = (Button )findViewById(R.id.btnstart);
        Button btnstop = (Button )findViewById(R.id.btnstop);
        
        
        toastmess.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(ToastMessage.this, "Hello! this is displayed message. thx", Toast.LENGTH_LONG).show();
				
			}
		});
        
btnstart.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onCreate();
				//Toast.makeText(ToastMessage.this, "Iratangiye muryoherwe!", Toast.LENGTH_LONG).show();
				
			}
			
		});
        btnstop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onDestroy();
				//Toast.makeText(Music.this, "Service stoped", Toast.LENGTH_LONG).show();
				
			}
		});
        
    }
   

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.toast_message, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    public void onCreate(){
    	Toast.makeText(this, "plse be quite song is started!!!!!!!!", Toast.LENGTH_LONG).show();
    	jon=MediaPlayer.create(this, R.raw.aa);
    	jon.setLooping(false);
    	jon.start();

    }
    public void onDestroy(){
    	Toast.makeText(this, "song is Stoped", Toast.LENGTH_LONG).show();
    	jon.pause();
    	
        }
}
