/** Automatically generated file. DO NOT MODIFY */
package com.pik.exointent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}