/** Automatically generated file. DO NOT MODIFY */
package com.Top.groupe3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}